package org.example;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        ReadFile objReadFile = new ReadFile();

        String filePath = System.getProperty("user.dir")+"\\src";
        objReadFile.readExcel(filePath,"myFile.xls","Sheet1");
    }
}
