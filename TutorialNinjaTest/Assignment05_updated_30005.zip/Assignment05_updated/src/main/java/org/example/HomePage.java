package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
    private WebDriver driver;

    private By myAccount = By.xpath("//a[@title='My Account']");
    private By register = By.xpath("//a[contains(text(),'Register')]");

    public HomePage(WebDriver driver){
        this.driver = driver;
    }

    public void clickOnRegister(){
        driver.findElement(myAccount).click();
        System.out.println("My Account is clicked");
        driver.findElement(register).click();
        System.out.println("register option is clicked");
    }
}
