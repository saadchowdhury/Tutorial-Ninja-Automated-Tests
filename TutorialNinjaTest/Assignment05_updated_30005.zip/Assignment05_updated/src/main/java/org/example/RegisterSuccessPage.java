package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RegisterSuccessPage {
    private WebDriver driver;
    private By successMessage = By.xpath("//*[@id='content']/h1");
    private By cont = By.xpath("//a[contains(text(),'Continue')]");

    public RegisterSuccessPage(WebDriver driver) {
        this.driver = driver;
    }

    public void successMessagecheck() {
        String currentURL = driver.getCurrentUrl();
        if(!currentURL.equalsIgnoreCase("http://tutorialsninja.com/demo/index.php?route=account/register"))
        {
            String expectedText = "Your Account has Been Created!";
            String actualText = driver.findElement(successMessage).getText();
            if (expectedText.equalsIgnoreCase(actualText)) {
                System.out.println("Account is created");
            } else {
                System.out.println("There is an Error");
            }
        }
        else{
            System.out.println("Error found");
            driver.quit();
        }

    }

    public void clickOnContinue() {
        driver.findElement(cont).click();
        System.out.println("Continue button is clicked");
    }
}
